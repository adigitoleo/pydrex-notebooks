%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DirectorEvolution -
% Program to calculate and plot fabric evolution using directors.
% Usage:
% DirectorsEvolution( filename_base, steps, nnx, nny, nnz, x0, y0, z0, NP, random_flag, plot_flag)
%
% INPUT:
% filename_base - a string giving the prefix of the filename. The filename
%   is assumed to be of the format base.xxxxx.dat, where xxxxx is a 5-digits 
%   padded time-step number (00001, 00032, 00125, etc)...
%
% steps - the time steps to be used. The program will load a velocity file
% for each step based on it's number. Assuming velocity file name is of the
% format 'VelocityField.xxxxx.dat, where xxxxx is a 5-digits padded
% time-step number (00001, 00032, etc)...
%
% nnx,nny,nnz - the number of nodes of the grid in each direction. For 2D
% problems assume nny=0
%
% initial_range - a 3x2 matrix stating the range of initial location of
% particles. Particles will be distrubuted between first two numbers give
% the range of locations in the X direction, second pair the range in the Y
% direction, third pair gives range in the Z direction.
%
% NP - total number of particles (for larger ranges of locations, use
% larger NP)
%
% random_flag - initial distribution of director orientation. If not
% random, only one director, of initial direction of n=(1,-1) is used.
%
% plot_flag - 1 for plotting during the run, 0 for not plotting.
%
% OUTPUT:
% phis_anis_steps - orientation of the A-axis (orthogonal to directors).
%        To obtain the mean A-axis orientation use:
%        for i=1:n, A(i) = mean_angles(phis_anis_steps(:,i)*180/pi), end
% perc_anis_steps  - currently not set. In the future will use the M-index
% phis_fse_steps - orientation of Finite Strain Ellipse major axis
% ln_fse_steps  - natural strain (ln(a/b))
% x_steps - Z positions of particles through the calculation
% z_steps - Z positions of particles through the calculation
% orientation_steps - mismatch between local LPO and local velocity vevctor
% ParticleMovie = animation, captures of the plotted propagation
%
% EXAMPLES:
% drip model - using drip60.00001.dat:
% DirectorsEvolution ('drip60', ones(1,500),33,241,[0.7 0.7; 0.1 0.1;
% 0.7 0.7], 40, 0, 1);
%
% Simple shear model - using simpleshearveloc.00001.dat:
% DirectorsEvolution ('simpleshearveloc', ones(1,60),8,67,[0.7 0.7;
% 0.1 0.1; 0.7 0.7], 40, 1, 0); toc
%
% Simple shear not from file (requires changing the function header format)
%DirectorsEvolution (x,y,y,0.*y,1:300, 33,241,[0.7 0.7; 0.1 0.1; 0.7
%0.7], 40, 1, 0); toc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [phis_anis_steps perc_anis_steps phis_fse_steps ln_fse_steps x_steps z_steps orientation_steps ParticleMovie] = ...
    DirectorsEvolution (filename_base, steps, nnx, nnz, initial_range, NP, random_flag, plot_flag)
%to start from a pre-loaded velocity data change to this:     DirectorsEvolutionSimple (x,z,VX,VZ, steps, nnx, nnz, initial_range, NP, random_flag, plot_flag)

%%% Initialization
warning('off','MATLAB:divideByZero')
y_position=0;
recrystal_threshold = 2;
num_recrys = 0;

%% Init grid
filename=strcat(filename_base,'.', sprintf('%05d', steps(1)), '.dat');

VelocityFileData = load (filename);
%If running directly from an Underworld output file:
%VelocityFileData(:,1:5) = VelocityFileData(:,[2 3 5 1 6]);

x = reshape(VelocityFileData(:,1), nnx, nnz);
z = reshape(VelocityFileData(:,2), nnx, nnz);
SIZE = size(x);
gridspaceX = (max(max(max(x))) - min(min(min(x))))./(SIZE(2)-1);
gridspaceZ = (max(max(max(z))) - min(min(min(z))))./(SIZE(1)-1);

%%% Init particle swarm
if (random_flag == 1)
    rand_angles = rand(1,NP)*pi/2+pi/2;
    nx = cos(rand_angles);
    nz = sin(rand_angles); 
else
    nx = ones(1,NP)./sqrt(2);
    nz = (ones(1,NP))./sqrt(2);
end
lengths = ones(1,NP);
x0=initial_range(1,:); y0=initial_range(2,:); z0=initial_range(3,:);
posx(1,:) = rand(1,NP)*(x0(2)-x0(1)) + x0(1);
posz(1,:) = rand(1,NP)*(z0(2)-z0(1)) + z0(1);
orientation = nx;
NX(1,:)=nx;
NZ(1,:)=nz;
LENGTHS(1,:)=lengths;

%%% Init graphics
if (plot_flag)
    scatter(posx, posz,100,[1-abs(orientation);1-abs(orientation);0.5*abs(orientation)]','filled');
    %quiver (x,z,vx,vz); hold on;
end

%%% Init finite strain tracking
F_old(1:NP,1,1) = 1; %eye(2); %[1 0; 0 1];
F_old(1:NP,2,2) = 1;
F_old(1:NP,1,2) = 0;
F_old(1:NP, 2,1) = 0;

%loop over time
counter=1;
for step=steps
%    filename=strcat(filename_base,'.', sprintf('%05d', step), '.dat');
    %VelocityFileData = load (filename);
    % if directly running an underworld output file
    %VelocityFileData(:,1:5) = VelocityFileData(:,[2 3 5 1 6]);

    %vx = VX;
    %vz = VZ;
    vx = reshape(VelocityFileData(:,3), nnx, nnz);
    vz = reshape(VelocityFileData(:,5), nnx, nnz);
    
    %%% Interpolate velocities at location of particles
    VxI = interp2(x,z,vx,posx(counter,:),posz(counter,:));
    VzI = interp2(x,z,vz,posx(counter,:),posz(counter,:));

    delta_tI = 0.25*min(gridspaceX, gridspaceZ)./sqrt(VxI.^2 + VzI.^2);
    
    %%% Calculate the velocity gradient field for the whole box and all particle locations
    [Fdvx_dx, Fdvx_dz] = gradient (vx,gridspaceX, gridspaceZ);
    [Fdvz_dx, Fdvz_dz] = gradient (vz, gridspaceX, gridspaceZ);

    %%% Define the velocity gradient tensor L at the location of each particle
    Lall(1,1,:) = interp2(x,z,Fdvx_dx, posx(counter,:), posz(counter,:));
    Lall(1,2,:) = interp2(x,z,Fdvx_dz, posx(counter,:), posz(counter,:));
    Lall(2,1,:) = interp2(x,z,Fdvz_dx, posx(counter,:), posz(counter,:));
    Lall(2,2,:) = interp2(x,z,Fdvz_dz, posx(counter,:), posz(counter,:));

    %%% Loop over the swarm
    for particle=1:NP

        L(1,1) = Lall(1,1,particle);
        L(1,2) = Lall(1,2,particle);
        L(2,1) = Lall(2,1,particle);

        L(2,2) = Lall(2,2,particle);
        %plot (counter, L(1,1),'r*')
        %plot (counter,L(1,2),'g*')
        %drawnow
        
        %pause
        %%% Interpolate velocities
        velocity_x = VxI(particle);
        velocity_z = VzI(particle);

        %-------------------------%
        % Finite Strain tracking  %
        %-------------------------%
        F = squeeze(F_old(particle,:,:));
        %%% Calculate Cauchy deformation tensor
        U = (inv(F))' * inv(F);

        %%% Eigenvalue decomposition of Cauchy deformation tensor
        [vectors,values] = eig(U);
        [max_value, max_index] = max(diag(values));
        Vecs(counter,particle,:) = vectors(:,max_index);

        max_strain_x = vectors(1,max_index);
        max_strain_z = vectors(2,max_index);
        fse_angle(counter,particle) = atan2(max_strain_z,max_strain_x);
        fse_ln(counter, particle) = 0.5.*log(max(diag(values))/min(diag(values)));
        
        delta_t = delta_tI(particle);

        %%% Calculate updated finite deformation gradient tensor F using a
        %%% less-accurate time-centered scheme (McKenzie 79)
        A(1,1) = 1 - (delta_t/2)*L(1,1);
        A(1,2) = -(delta_t/2)*L(1,2);
        A(2,1) = -(delta_t/2)*L(2,1);
        A(2,2) = 1 - (delta_t/2)*L(2,2);
        B(1,1) = 1 + (delta_t/2)*L(1,1);
        B(1,2) = (delta_t/2)*L(1,2);
        B(2,1) = (delta_t/2)*L(2,1);
        B(2,2) = 1 + (delta_t/2)*L(2,2);
        F_new = inv(A) * B * squeeze((F));

        %Remember for next step
        F_old(particle,:,:) = F_new;


        %------------------------------%
        % Directors Evolution tracking %
        %------------------------------%
                dt=delta_t;
               
                nx(particle) = nx(particle)/sqrt(nx(particle)^2+nz(particle)^2);
                nz(particle) = nz(particle)/sqrt(nx(particle)^2+nz(particle)^2);
                orientation(particle) = dot([nx(particle),nz(particle)], [velocity_x,velocity_z]);
        
                dvx_dx = L(1,1);
                dvx_dz = L(1,2);
                dvz_dx = L(2,1);
                dvz_dz = L(2,2);
        
                timeDeriv(1) = -dvx_dx*nx(particle) - dvz_dx*nz(particle);
                timeDeriv(2) = -dvx_dz*nx(particle) - dvz_dz*nz(particle);
                nx_new = nx(particle)+timeDeriv(1)*dt;
                nz_new = nz(particle)+timeDeriv(2)*dt;
                elongation = sqrt(nx_new^2+nz_new^2);
                lengths(particle) = elongation*lengths(particle);
                LENGTHS(counter, particle) = lengths(particle);
        
                Vmag = sqrt(velocity_x^2+velocity_z^2);
                if (Vmag ~= 0)
                    normal_vx = velocity_x/(sqrt(velocity_x^2+velocity_z^2));
                    normal_vz = velocity_z/(sqrt(velocity_x^2+velocity_z^2));
                else
                    normal_vx = 0;
                    normal_vz = 0;
                end
        
                %%%% Ad-hoc making the particles align with shear direction for strains greater than 500%
                %%%% using tracking of elongation:
                if (lengths(particle) < recrystal_threshold)
                    nx(particle) = nx_new/sqrt(nx_new^2+nz_new^2);
                    nz(particle) = nz_new/sqrt(nx_new^2+nz_new^2);
                else
                    %if we have stretched beyomd the threshold, make the director
                    %ORTHOGONAL to the local velocity vector, represing alignment
                    %of the EASY glive plane with the local velocity.
                    [isa_direction, isa_defined] = CalcISA(L);
                    if (isa_defined == 1) %align director NORMAL to the ISA
                           nx(particle) = isa_direction(2);
                           nz(particle) = isa_direction(1);
                    else
                       %normalize director length
                       n_newMag = sqrt(sum([nx_new, nz_new].^2));
                       nx(particle) = nx_new/n_newMag;
                       nz(particle) = nz_new/n_newMag;
                    end
                    num_recrys = num_recrys+1;
                end
                if (lengths(particle) > recrystal_threshold*1.1)
                    lengths(particle) = recrystal_threshold;
                end

                NX(counter+1, particle) = nx(particle);
                NZ(counter+1, particle) = nz(particle);
        
                orientation(particle) = dot([nx(particle),nz(particle)], [normal_vx,normal_vz]);

        % end of particles orientation seection
        %----------

        %------------------------------%
        % Particles Advection in Space %
        %------------------------------%

        %%% Advection using Euler method: Xnew = Xold + V*dt
        %        new_posx = posx(counter,particle) + delta_t*velocity_x;
        %        new_posz = posz(counter,particle) + delta_t*velocity_z;
        
        %%% Advection using 4th order Runge-Kutta method
        % X direction:
        k1 = delta_t*velocity_x;
        trial_velocity_x = interp2(x,z,vx,posx(counter,particle)+k1/2,posz(counter,particle));
        k2 = delta_t*trial_velocity_x;
        trial_velocity_x = interp2(x,z,vx,posx(counter,particle)+k2/2,posz(counter,particle));
        k3 = delta_t*trial_velocity_x;
        trial_velocity_x = interp2(x,z,vx,posx(counter,particle)+k3,posz(counter,particle));
        k4 = delta_t*trial_velocity_x;
        new_posx = posx(counter, particle) + (k1 + 2*k2 + k3*2 + k4)/6;
        
        % X direction:
        k1 = delta_t*velocity_z;
        trial_velocity_z = interp2(x,z,vz,posx(counter,particle),posz(counter,particle)+k1/2);
        k2 = delta_t*trial_velocity_z;
        trial_velocity_z = interp2(x,z,vz,posx(counter,particle),posz(counter,particle)+k2/2);
        k3 = delta_t*trial_velocity_z;
        trial_velocity_z = interp2(x,z,vz,posx(counter,particle),posz(counter,particle)+k3);
        k4 = delta_t*trial_velocity_z;
        new_posz = posz(counter, particle) + (k1 + 2*k2 + k3*2 + k4)/6;
        
        %%% updating vectors
        posx(counter+1,particle) = new_posx;
        posz(counter+1,particle) = new_posz;
        if (find (isnan(posx)))
            pause;
        end
        if (find (isnan(posz)))
            pause;
        end

        %%% Impose periodic boundary conditions on particle advection
        if (new_posz > (max(max(z))))
            posz(counter+1,particle) = new_posz-(max(max(z))-min(min(z)))-gridspaceZ;
        else
            if (new_posz< min(min(z)))
                posz(counter+1,particle) = new_posz+(max(max(z))-min(min(z)))+gridspaceZ;
            end
        end
        if (new_posx > max(max(x)))
            %           return
            posx(counter+1,particle) = new_posx-(max(max(x))-min(min(x)))-gridspaceX;
        else
            if (new_posx < min(min(x)))
                posx(counter+1,particle) = new_posx+(max(max(x))-min(min(x)))+gridspaceX;
            end
        end

        % Plot directors as lines
        %     if (mod(counter,10) == 0)
        %         h = line ([new_posx, new_posx+nx/scaling_factor*2], [new_posz, new_posz+nz/scaling_factor*2]);
        %         set (h, 'Color', 'k','LineWidth',2);
        %     end
    end %end for particle=1:NP

    %------------------------------%
    % Plotting section             %
    %------------------------------%

    %plot orientations map
    if ((mod(counter,30) ==0) && (plot_flag == 1))
        quiver(x,z,vx,vz,'b');
        hold on;
        scatter(squeeze(posx(counter,:)), squeeze(posz(counter,:)),10,'r');%[1-abs(orientation);1-abs(orientation);0.5*abs(orientation)]','filled');
        title (strcat('t = ', num2str(counter*delta_t)));
        scaling_factor = 20/mean(lengths);

        %%%% plot lines for easy glide planes - normal to directors!!
%                h = line ([posx(counter+1, :)-nz(:)'./scaling_factor ; posx(counter+1, :)+nz(:)'./scaling_factor], ...
%                    [posz(counter+1, :)+nx(:)'./scaling_factor; posz(counter+1, :)-nx(:)'./scaling_factor]);
%                %for i=1:NP, set(h(i),'Color', [1-(i)^2/NP^2 i^3/NP^3 i^4/NP^4]); end
%                 set(h, 'Color', 'k');
% %               line_length = sqrt((2*nz(:)/scaling_factor)^2 + (2*nx(:)/scaling_factor)^2);
                

                phis_anis  = mean_angles( (atan2(nz, nx)+pi/2)*180/pi)*pi/180;
                h = line ([posx(counter+1, :)-cos(phis_anis)./scaling_factor ; posx(counter+1, :)+ cos(phis_anis)./scaling_factor], ...
                   [posz(counter+1, :)-sin(phis_anis)./scaling_factor; posz(counter+1, :)+sin(phis_anis)./scaling_factor]);
 

        %%%% Plot lines for FSE finite strain ellipse major axis
%         h = line ([posx(counter+1, particle)- cos(fse_angle(counter,particle))./scaling_factor; posx(counter+1, particle)+cos(fse_angle(counter,particle))./scaling_factor], ...
%             [posz(counter+1, particle) - sin(fse_angle(counter,particle))./scaling_factor; posz(counter+1, particle)+sin(fse_angle(counter,particle))./scaling_factor]);
%         set (h, 'Color', 'r')

        axis ([min(min(x)) max(max(x)), min(min(z)) max(max(z))]);
        axis equal
        drawnow;
        ParticleMovie(counter) = 0; %getframe(gca);
    else
        if (plot_flag == 2)
            figure(4);
            hold on
            plot (counter, mod(fse_angle(counter,particle),pi)*180/pi,'b.');
            plot (counter, mod(atan2(nz, nx),pi)*180/pi,'r.');
            set (gca, 'Xlim', [0 length(steps)]);
            drawnow;
        end
        ParticleMovie(counter)=0;
    end
    counter = counter + 1

end %end for dt=1:T

%------------------------------%
% Finializing step             %
%------------------------------%

%%% Translate internal variables values to output data
phis_anis_steps  = atan2(NZ', NX')+pi/2; %anis gives orientation of easy glide plane, normal to directors
perc_anis_steps  = ones(size(NZ)); % Later will add calculation using M-index
phis_fse_steps  = fse_angle;
ln_fse_steps  = fse_ln;
x_steps  = posx;
z_steps = posz;
orientation_steps  = orientation;

%%%%%%%%%% Auxiliary functions  %
%-------------------------------%

function angle = angle_between_vectors(v1,v2)
angle = acos (dot(v1,v2));
angle = angle*180/pi;
%-------------------------------%
%%% CalcISA - function to calculate the Infinite Strain axis given a
%%% velocity gradient tensor L


%%% CalcISA - function to calculate the Infinite Strain axis given a
%%% velocity gradient tensor L

function [ISA, isa_defined_flag] = CalcISA (L)

%%%Find eigenvalues and eigenvectors of L
[u,v] = eig(L);

%%% One eigen value is identically zero--> simple shear. Note that in such
%%% cases many times the other eigenvalues will not be zero but very very
%%% small complex numbers. But this is NOT a case of infinite spinning...
if (min(diag(v)) == 0)
    L = transpose(L);
    Finf = exp(L*100); %% K&R2004 state that t=75 is enough for this calculation
    Uinf = transpose(Finf)*Finf;
    [u,v] = eig(Uinf);
    [max_eval, max_index] = max(diag(v));
    ISA = u(:,max_index);   
    isa_defined_flag = 1;
else
%%% There are complex numbers, so the ISA is not defined due to infinite rotation 
    if (any(imag(diag(v))))
        ISA = [-1, -1, -1]; 
        isa_defined_flag = 0;
    else
%%% We can use the Sylvester's formula to calculate the Uinf without taking
%%% the matrix exponent. See K&R2004 Appendix B dor details on equations
        I = eye(2);
        L=transpose(L);
        [lambdas, indices] = sort(diag(L)); %%puts maximum in the last entry
%%3D        Faux = ((L-lambdas(1)*I)*(L-lambdas(2)*I))./((lambdas(3)-lambdas(1))*(lambdas(3)-lambdas(2)));
%%2D
        Faux = (L-lambdas(1)*I)/(lambdas(2)-lambdas(1));
        Uaux = transpose(Faux)*Faux;
        [u,v] = eig(Uaux);
        [max_eval, max_index] = max(diag(v));
        ISA = u(:,max_index);   
        isa_defined_flag = 1;   
    end
end

% 
% 
% 
% function ISA = CalcISA (L)
% 
% %%%Find eigenvalues and eigenvectors of L
% [u,v] = eig(L);
% 
% %%% One eigen value is identically zero--> simple shear. Note that in such
% %%% cases many times the other eigenvalues will not be zero but very very
% %%% small complex numbers. But this is NOT a case of infinite spinning...
% if (min(diag(v)) == 0)
%     Lt = transpose(L);
%     Finf = exp(Lt*100); %% K&R2004 state that t=75 is enough for this calculation
%     Uinf = transpose(Finf)*Finf;
%     [u,v] = eig(Uinf);
%     [max_eval, max_index] = max(diag(v));
%     ISA = u(:,max_index);   
%     isa_defined_flag = 1;
% else
% %%% There are complex numbers, so the ISA is not defined due to infinite rotation 
%     if (any(imag(diag(v))))
%         ISA = [-1, -1, -1]; 
%         isa_deifned_flag = 0;
%     else
% %%% We can use the Sylvester's formula to calculate the Uinf without taking
% %%% the matrix exponent. See K&R2004 Appendix B dor details on equations
%         I = eye(2);
%         L=transpose(L);
%         [lambdas, indices] = sort(diag(L)); %%puts maximum in the last entry
% %%3D        Faux = ((L-lambdas(1)*I)*(L-lambdas(2)*I))./((lambdas(3)-lambdas(1))*(lambdas(3)-lambdas(2)));
% %%2D
%         Faux = (L-lambdas(1)*I)/(lambdas(2)-lambdas(1));
%         Uaux = transpose(Faux)*Faux;
%         [u,v] = eig(Uaux);
%         [max_eval, max_index] = max(diag(v));
%         ISA = u(:,max_index);   
%         isa_defined_flag = 1;   
%     end
% end
% 
