%%%%%%%%%%%%%
function m=angle_mean(a,b,wa,wb)
[a,wa, b, wb];
a=mod(a,180);
b=mod(b,180);
if (a<b)
  tmp=a;
  a=b;
  b=tmp;
  tmp=wa;
  wa=wb;
  wb=tmp;
end
d=a-b;
if (d>90)
  d = d-180;
end
m = mod(a-(wb/(wa+wb))*d,180);

