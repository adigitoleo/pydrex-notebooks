%%%%%%%%%%%%%%%%%%%%%%
function temp_mean = mean_angles (vector)
temp_mean = vector(1);
for i=2:length(vector)
   if (temp_mean > vector(i))
       temp_mean = angle_mean(temp_mean, vector(i), i-1, 1);
   else
       temp_mean = angle_mean(vector(i), temp_mean, 1 ,i-1);
   end
end
